create table AssessmentScore(id number,modulename varchar2(20),mpt number,mtt number,ass_marks number,total number,grade number);


create table trainees(id number, name varchar2(20));
insert into trainees values(100,'Shwetha');
